Technology used:
    React
    Hooks
    Node
    Express

    Font Awesome
    Google Fonts
    Material UI

    AWS S3
    AWS Elastic Beanstalk
    AWS RDS
    AWS E2