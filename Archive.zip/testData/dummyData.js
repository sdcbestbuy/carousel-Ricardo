const data = [
    {
      id: 1,
      name: 'The last of us part 2',
      image: 'https://circuit-city-images.s3.us-east-2.amazonaws.com/thelastofus.jpg',
      price: 200,
      rating: 4.6,
      category: 'Games'
    },
    {
      id: 2,
      name: 'Left 4 Dead 2',
      image: 'https://circuit-city-images.s3.us-east-2.amazonaws.com/left4dead.jpg',
      price: 200,
      rating: 4.6,
      category: 'Games'
    },
    {
      id: 3,
      name: 'Nextel Indestructaphone',
      image: 'https://circuit-city-images.s3.us-east-2.amazonaws.com/nextel.jpg',
      price: 200,
      rating: 4.6,
      category: 'Construction'
    },
    {
      id: 4,
      name: 'Nintendo Switch',
      image: 'https://circuit-city-images.s3.us-east-2.amazonaws.com/nintendoswitch.jpg',
      price: 200,
      rating: 4.6,
      category: 'Construction'
    },
    {
      id: 5,
      name: 'Palm Pilot',
      image: 'https://circuit-city-images.s3.us-east-2.amazonaws.com/palmpilot.jpg',
      price: 200,
      rating: 4.6,
      category: 'Construction'
    },
    {
      id: 6,
      name: 'Printer Fax',
      image: 'https://circuit-city-images.s3.us-east-2.amazonaws.com/printer.jpg',
      price: 200,
      rating: 4.6,
      category: 'Construction'
    }
  ];

  module.exports = {

    data,
  }